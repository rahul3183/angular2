import { Component } from '@angular/core';

@Component({
  selector: 'rev',
  template: `
	Type <input [(ngModel)]="Type"  (keyup.enter)="show()"/>
	<br><br>
    City <input [(ngModel)]="City"  (keyup.enter)="show()"/>
   <br><br>
   Capacity <input [(ngModel)]="Capacity"  (keyup.enter)="show()"/>
   <br><br>
   Duration <input [(ngModel)]="Duration"  (keyup.enter)="show()"/>
   <br><br>
   <button (click)="show()">Submit</button>


              `,
  styleUrls: ['./app.component.css']
})
export class reserveComponent {
Type =''
City =''
Capacity =''
Duration = ''
show()
{
	console.log("section :"+this.Type);
	console.log("section :"+this.City);
	console.log("section :"+this.Capacity);
	console.log("section :"+this.Duration);
}



  
}