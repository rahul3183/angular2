import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { twbComponent } from './twb.component';
import { AppComponent } from './app.component';
import { reserveComponent } from './reserve.component';





@NgModule({
  declarations: [
    AppComponent,
    
    twbComponent,
    reserveComponent

  ],
  imports: [
    FormsModule,
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
